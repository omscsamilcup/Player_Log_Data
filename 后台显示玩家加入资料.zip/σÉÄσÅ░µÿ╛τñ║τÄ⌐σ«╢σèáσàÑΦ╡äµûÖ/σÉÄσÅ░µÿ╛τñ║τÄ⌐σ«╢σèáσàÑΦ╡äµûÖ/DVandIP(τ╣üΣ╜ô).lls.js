//LiteLoaderScript Dev Helper
/// <reference path="d:\/Library/JS/Api.js" />


file.createDir('plugins/OMSC插件')
if (file.exists('plugins/OMSC插件/玩家data/data.json') == false) {
    file.writeTo('plugins\\OMSC插件\\玩家data\\data.json', '{ }');
}
if (file.exists('plugins/OMSC插件/玩家data/playercount.json') == false) {
    file.writeTo('plugins\\OMSC插件\\玩家data\\playercount.json', '{ }');
}
var plname = 'OMSC顯示玩家加入設備和IP(console)'
var version = { plver: '2.0.0' }
var info = { 'author': "samilcup(OMSC團隊)" }
ll.registerPlugin("加入顯示資料", "玩家加入時顯示玩家資料", [2, 0, 0], { info: "author" }); 

mc.listen('onServerStarted', () => {
    var ip = {}
    var path = 'plugins\\OMSC插件\\玩家data\\data.json'
    mc.listen("onPreJoin", function(player) {
        let dv = player.getDevice()
        let pl = player
        ip = data.parseJson(file.readFrom(path))
        ip[player.realName] = {}
        ip[player.realName].NickName = player.name
        ip[player.realName].IP = dv.ip
        ip[player.realName].OS = dv.os
        file.writeTo(path, JSON.stringify(ip, null, "\t"))
        colorLog("red", `${pl.realName}加入伺服器，已經將該玩家的資料存儲了！`)
    });
    var firsttime = {}
    var first = 'plugins\\OMSC插件\\玩家data\\playercount.json'
    mc.listen("onPreJoin", function(player) {
        firsttime = data.parseJson(file.readFrom(first))
        firsttime[player.realName] = player.realName
        file.writeTo(first, JSON.stringify(firsttime, null, "\t"))
        colorLog("blue", `玩家${player.realName}加入了本伺服器，已為你進行玩家統計！`)
    });
    mc.listen('onJoin', function(player) {
        let dv = player.getDevice()
        colorLog("yellow", `玩家${player.realName}使用設備${dv.os},玩家IP是:${dv.ip},玩家加入時的延遲:${dv.avgPing}ms`)
    });
    log(`${plname} 加載成功！ 插件名稱:${plname}插件版本:${version.plver} 作者:${info.author}`)
    colorLog("green", `謝謝samilcup製作的玩家加入顯示設備和IP插件！
===========================
█████  ██ ██  █████  █████
█   █  █ █ █  █      █
█   █  █ █ █  █████  █
█   █  █ █ █      █  █
█████  █ █ █  █████  █████
============================
`)
})