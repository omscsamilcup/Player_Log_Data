//LiteLoaderScript Dev Helper
/// <reference path="d:\/Library/JS/Api.js" />

var plname = 'OMSC显示玩家加入设备和IP(console)'
var version = '3.0.0'
var author = 'samilcup(OMSC团队)'
ll.registerPlugin(plname, '玩家进入伺服器console显示玩家的资料(LiteLoader(LL))', [3, 0, 0], info)

var path = 'plugins\\OMSC插件\\玩家data\\data.json'
var first = 'plugins\\OMSC插件\\玩家data\\playercount.json'

mc.listen("onServerStarted", () => {

    file.createDir('plugins/OMSC插件')
    if (file.exists('plugins/OMSC插件/玩家data/data.json') == false) {
        file.writeTo('plugins\\OMSC插件\\玩家data\\data.json', '{ }');
    }

    file.createDir('plugins/OMSC插件')
    if (file.exists('plugins/OMSC插件/玩家data/playercount.json') == false) {
        file.writeTo('plugins\\OMSC插件\\玩家data\\playercount.json', '{ }');
    }

    mc.listen("onServerStarted", () => {
        mc.listen('onPreJoin', function(player) {
            let dv = player.getDevice()
            ip = data.parseJson(file.readFrom(path))
            ip[player.realName] = {}
            ip[player.realName].玩家ID = player.realName
            ip[player.realName].IP = dv.ip
            ip[player.realName].OS = dv.os
            file.writeTo(path, JSON.stringify(ip, null, "\t"))
            colorLog("red", `${player.realName}首次加入伺服器， 已经将该玩家的资料存储了！ `)
        });
        mc.listen("onPreJoin", function(player) {
            player = data.parseJson(file.readFrom(first))
            player[player.realName] = player.realName
            file.writeTo(first, JSON.stringify(player, null, "\t"))
            colorLog("blue", `玩家${player.realName}第一次加入本伺服器， 你伺服器玩家数量已被统计！ `)
        });
        mc.listen("onJoin", function(player) {
            let dv = player.getDevice()
            colorLog("yellow", `玩家${player.name}使用设备${dv.os}, 玩家IP是:${dv.ip},玩家加入时的延迟:${dv.avgPing}`)
        })
    });
    log(`${plname}加载成功！ 插件名称:${plname}插件版本:${version}作者:${author}`)
    colorLog("green", ` samilcup制作的玩家加入显示设备和IP插件！ 
    ===========================
    █████  ██ ██  █████  █████
    █   █  █ █ █  █      █
    █   █  █ █ █  █████  █
    █   █  █ █ █      █  █
    █████  █ █ █  █████  █████
    ============================
                                            `)
})